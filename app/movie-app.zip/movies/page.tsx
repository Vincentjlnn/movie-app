// app/movies/page.tsx
import MovieList from "../components/movieList";

export default function MoviesPage() {
  return <MovieList />;
}
