// app/movies/[id]/page.tsx
"use client";

import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";

// 1. (Best Practice) Buat tipe untuk props, hindari 'any'
type MovieDetailProps = {
  params: {
    id: string; // 'id' dari URL selalu string
  };
};

export default function MovieDetail({ params }: MovieDetailProps) {
  const router = useRouter();
  const { id } = params;

  // 2. (Best Practice) Beri tipe 'string' pada state Anda
  const [movie, setMovie] = useState<string>("");

  useEffect(() => {
    const saved = localStorage.getItem("movies");
    if (!saved) return;

    try {
      // 3. (Best Practice) Beri tipe pada 'list' yang Anda parse
      const list: string[] = JSON.parse(saved);

      // 4. (FIX UTAMA) Ubah 'id' (string) menjadi 'number' untuk indeks
      const index = Number(id);

      // 5. Gunakan 'index' (number) untuk mengambil data dari array
      //    Juga, beri nilai default yang lebih jelas jika tidak ditemukan
      setMovie(list[index] ?? "Film tidak ditemukan");
    
    } catch (error) {
      // (Best Practice) Tangani jika JSON.parse gagal
      console.error("Gagal mem-parse 'movies' dari localStorage", error);
      setMovie("Data film rusak");
    }
    
  }, [id]); // Dependency array sudah benar menggunakan 'id'

  return (
    <div className="container mt-5">
      <div className="card p-4">
        <h3>Detail Film</h3>
        <p className="mt-3">Judul: {movie}</p>

        <button className="btn btn-secondary mt-3" onClick={() => router.back()}>
          Back
        </button>
      </div>
    </div>
  );
}