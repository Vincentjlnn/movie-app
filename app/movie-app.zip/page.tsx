// app/page.tsx
export default function Home() {
  return (
    <div className="container py-5">
      <h1>Vincent Julian</h1>
      <p>NIM: 535240126</p>
      <p>Topik Project: Daftar Film Favorit</p>
    </div>
  );
}
