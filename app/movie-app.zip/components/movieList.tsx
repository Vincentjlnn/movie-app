// 1. Tambahkan "use client" di baris paling atas
"use client";

// 2. Import useState dari react
import { useState } from "react";

export default function Movielist() {
  // 3. Definisikan state untuk menyimpan nilai input
  const [text, setText] = useState("");

  // 4. Definisikan fungsi untuk tombol "Add"
  const addMovie = () => {
    // Untuk saat ini, kita hanya akan log ke konsol
    console.log("Film baru ditambahkan:", text);
    // Anda bisa menambahkan logika lain di sini (misal: membersihkan input)
    setText(""); 
  };

  // (Saya juga menghapus tanda ; di baris 29 file lama Anda yang sepertinya salah tempat)

  return (
    <div className="container mt-4">
      <h2>Daftar Film Favorit</h2>

      <div className="d-flex gap-2 mt-3">
        <input
          className="form-control"
          value={text} // Sekarang 'text' sudah terdefinisi
          onChange={(e) => setText(e.target.value)} // 'setText' juga sudah terdefinisi
          placeholder="Masukkan judul film"
        />
        <button className="btn btn-primary" onClick={addMovie}> {/* 'addMovie' juga sudah terdefinisi */}
          Add
        </button>
      </div>

      {/* Anda mungkin ingin menampilkan daftar film di sini nanti */}
    </div>
  );
}